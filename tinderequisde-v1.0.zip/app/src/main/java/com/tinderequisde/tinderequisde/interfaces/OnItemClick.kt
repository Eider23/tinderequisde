package com.tinderequisde.tinderequisde.interfaces

import com.tinderequisde.tinderequisde.models.ProfileInfo

interface OnItemClick {
    fun onItemClick(profile: ProfileInfo)
}
